from django.apps import AppConfig


class FaircomConfig(AppConfig):
    name = 'faircom'
